# Resources

Bu klasör, üretim derlemesinde uygulamayla birlikte paketlenen statik kaynakları içerir.

## İkonlar

Derleme öncesinde aşağıdaki ikonları bu klasöre eklemelisiniz:

| Dosya | Platform | Boyut |
| --- | --- | --- |
| `icon.ico` | Windows (NSIS) | en az 256×256 (256, 128, 64, 48, 32, 16 katmanlı) |
| `icon.icns` | macOS (DMG) | en az 512×512 katmanlı |
| `icon.png` | Linux (AppImage) | 512×512 |

İkon yoksa `electron-builder` derlemesi başarısız olabilir veya varsayılan Electron ikonu kullanılır.

## Sözlükler

Yazım denetimi için Hunspell `.aff` / `.dic` dosyaları kullanılır. Varsayılan olarak `nspell` ile birlikte aşağıdaki paketler kullanılır ve `node_modules` içinden otomatik olarak yüklenir:

- `dictionary-tr` (Türkçe)
- `dictionary-en` (İngilizce)
- `dictionary-fr` (Fransızca)
- `dictionary-it` (İtalyanca)

Bu paketler `electron-builder.yml` içinde `asarUnpack` listesindedir, böylece çalışma zamanında erişilebilir kalır.

### Özel sözlükler (opsiyonel)

Kendi sözlüklerinizi eklemek isterseniz aşağıdaki yapıyı kullanın:

```
resources/dictionaries/
  tr/
    index.aff
    index.dic
  en/
    index.aff
    index.dic
  fr/
    ...
  it/
    ...
```

Bu dosyalar varsa, ana süreç bunları `node_modules` paketlerine tercih edebilir (uygulama tarafında elle yönlendirme gerekir).

## Diğer

- Bu klasördeki tüm dosyalar `extraResources` olarak `release/resources/` altına kopyalanır.
